# Ansible + OpenShift (oc CLI) – Directory-per-app model

This repo is designed for Ansible Tower/AWX and pipeline runners (Jenkins / Digital.AI Release / XLR).
It runs everything locally (no SSH hosts) by executing `oc` commands from the runner container.

## Layout
- `deploy.yml` – single playbook that:
  - loads global + env config from `group_vars/all.yml`
  - discovers `apps/*/config.yml`
  - optionally filters by `apps_select`
  - runs roles: `oc_auth` → `oc_build` → `oc_apply`
- `apps/<app>/config.yml` – one file per deployment/app; add a new folder to extend.
- `roles/*` – minimal roles using `oc` commands.

## Requirements (on the runner / Tower Execution Environment)
- `oc` CLI available
- network reachability to the OpenShift API
- credentials supplied via extra-vars (recommended via Tower survey or XLR secure vars)

## Typical run (pipeline)
```bash
ansible-playbook deploy.yml \
  -e target_env=dev \
  -e image_tag=1.2.3-45 \
  -e oc_password='***'
```

Optional: deploy only specific apps:
```bash
ansible-playbook deploy.yml -e target_env=dev -e apps_select="proxy,triton-model-a" -e oc_password='***'
```

## Credentials
- Username is defaulted to `ac74305devops` (override with `-e oc_username=...`).
- Password should be passed as `oc_password` (Tower Survey Password field / XLR secure var).

## Notes / TODOs you may want to wire next
- Registry push secrets for BuildConfig output to external registry.
- Replace `oc apply -f` with `kubernetes.core.k8s` for better idempotency (optional).
- Add HPA/PDB, SCC, serviceAccount, imagePullSecrets if needed.


## Note on module names
This repo uses short module names (`command`, `shell`, etc.) which is common in many Tower/AWX examples. Fully qualified names like `ansible.builtin.command` are also valid and often recommended, but not required.
