# Ultra-simple OpenShift deploy (oc CLI) – one playbook, directory-per-app, XLR-friendly

This package is designed for Ansible Tower/AWX execution environments and Digital.ai Release (XLR).
It runs `oc` commands locally (no SSH hosts) and uses XLR runtime variables:
- `published_artifact_url` -> passed to Ansible as `wheel_url`
- `applicationName` -> passed to Ansible as `apps_select`

## What you edit
- Add/modify apps by creating `apps/<app_dir>/config.yml`
- For mapping from XLR `applicationName` to your app directory, set `aliases` in each app config.

## Run-time inputs (from XLR/Tower extra vars)
- `target_env` (lab/dev/uat/prod/dr)
- `apps_select` (value from XLR `${applicationName}`)
- `wheel_url` (value from XLR `${published_artifact_url}`) – required for python_whl builds
- `image_tag` (optional, e.g. `${buildJobNumber}`)

## Credentials
- `oc_username` and `oc_cmd` are in `group_vars/all.yml`
- `oc_password` should be stored in Ansible Vault (see `group_vars/all/vault.yml` placeholder) and decrypted via Tower Vault Credential.

## One playbook
- `playbook_main.yaml` calls roles only:
  - `app_discover` -> loads app configs and selects the right app(s)
  - `oc_auth` -> `oc login` and `oc project`
  - `oc_build` -> builds image from wheel (only for `kind: python_whl`)
  - `oc_apply` -> applies K8s/OpenShift objects (deploy)

## XLR config
See `xlr/xlr_config_all_env_one_step.json` (single step per environment; one playbook).
